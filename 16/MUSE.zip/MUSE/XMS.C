////////////////////////////////////////////////////
//
// XMS routines - uses the MENU.C & LIB.C routines for output
//
////////////////////////////////////////////////////
#include "muse.h"
#pragma hdrstop


unsigned XMSavail;
void far *XMSdriver;

////////////////////////////////////////////////////
//
// Initialize the XMS memory
//
////////////////////////////////////////////////////
void InitXMS(void)
{
 //
 // See if XMS driver is present...
 //
 asm	mov	ax,0x4300
 asm	int	0x2f
 asm	cmp	al,0x80		// installed?
 asm	je	Present

 ErrDialog("You poor bastard! I refuse\n"
	   "to work without Extended\n"
	   "Memory! Goodbye!"," I Suck ");
 Quit("No Extended Memory Driver found!");

 //
 // YES! We found an XMS driver! Now we
 // need to get the XMS driver's entry address...
 //
 Present:
 asm	mov	ax,0x4310
 asm	int	0x2f
 asm	mov	WORD PTR XMSdriver,bx
 asm	mov	WORD PTR XMSdriver+2,es

 XMSTotalFree();
}


////////////////////////////////////////////////////
//
// Report an XMS error, if any
//
////////////////////////////////////////////////////
void XMSerror(void)
{
 if (_AX==0)
   switch(_BL)
   {
    case 0xa0: Quit("Not enough Extended Memory available!");
    default: Quit("Unknown XMS Memory Error!");
   }
}

////////////////////////////////////////////////////
//
// Allocate XMS memory
//
////////////////////////////////////////////////////
int XMSAllocate(long size)
{
 _DX=(size+1023)/1024;
 CallXMS(9);
 XMSerror();
 return _DX;
}

////////////////////////////////////////////////////
//
// Free XMS memory
//
////////////////////////////////////////////////////
void XMSFreeMem(int handle)
{
 _DX=handle;
 CallXMS(10);
 XMSerror();
}


////////////////////////////////////////////////////
//
// Return XMS memory available
//
////////////////////////////////////////////////////
unsigned XMSTotalFree(void)
{
 CallXMS(8);
 XMSerror();
 XMSavail=_DX;
 return XMSavail;
}

////////////////////////////////////////////////////
//
// Move XMS memory
//
////////////////////////////////////////////////////
void XMSmove(int srchandle,long srcoff,int desthandle,long destoff,long size)
{
 struct { long bsize;
	  int shandle;
	  long soff;
	  int dhandle;
	  long doff;
	} XMSparms;

 unsigned DSreg,SIreg;

 XMSparms.bsize=size;
 XMSparms.shandle=srchandle;
 XMSparms.dhandle=desthandle;
 XMSparms.soff=srcoff;
 XMSparms.doff=destoff;

 DSreg=FP_SEG(&XMSparms);
 SIreg=FP_OFF(&XMSparms);

 asm	push	ds
 asm	push	si
 asm	mov	si,SIreg
 asm	mov	ds,DSreg

 CallXMS(11);

 asm	pop	si
 asm	pop	ds

 XMSerror();
}